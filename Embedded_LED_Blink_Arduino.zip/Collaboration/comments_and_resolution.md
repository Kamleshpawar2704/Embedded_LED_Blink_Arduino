**Collaborators:**
- Kamlesh Pawar (Developer)
- Teammate A (Tester)
- Teammate B (Reviewer)

**Summary:**
1. Kamlesh created repo and uploaded code.
2. Teammate A tested and logged issues.
3. Kamlesh resolved issues.
4. Teammate B verified final version.
5. All confirmed successful output.
